/****************************************************************************


memstat.h

produced by VisualAge Resource Workshop


*****************************************************************************/

#define IDD_MAIN	100
#define IDS_INFO	1000
#define ID_TIMER1       1

#define UPD_LOW         5000
#define UPD_NORMAL      1000
#define UPD_HIGH        100



