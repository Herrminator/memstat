#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>

#include <memstat.h>

BOOL bOnTop;

CHAR prcView[256];
CHAR prcViewExe[256];

COLORREF bk;
COLORREF fg;
COLORREF cust[16];

HBRUSH hbr;

int updWindowText = 0;

void updateInfo(HWND hwnd)
{
  MEMORYSTATUS ms;
  CHAR buf[80];
  struct tm *t;
  time_t lt;
  
  time(&lt);
  t = localtime(&lt);
  
  ms.dwLength = sizeof(ms);
  GlobalMemoryStatus(&ms);
  
  sprintf(buf, "PHYS %luK/%luK  PAGE %luK/%luK  %02d:%02d", 
          ms.dwAvailPhys / 1024, ms.dwTotalPhys / 1024,
          ms.dwAvailPageFile / 1024, ms.dwTotalPageFile / 1024,
          t->tm_hour, t->tm_min);
  
  SetDlgItemText(hwnd, IDS_INFO, buf);
  if (updWindowText)
    SetWindowText(hwnd, buf);
}

void SaveSettings(HWND hwnd)
{
  RECT r;
  HKEY k;
  DWORD d;
  
  GetWindowRect(hwnd, &r);
  if (RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\DITJ\\MemStat",
                     0, NULL, 0, KEY_WRITE, NULL, &k, &d) != ERROR_SUCCESS)
    return;
    
  RegSetValueEx(k, "onTop", 0, REG_BINARY, (LPCSTR) &bOnTop, sizeof(bOnTop));
  RegSetValueEx(k, "xPos",  0, REG_BINARY, (LPCSTR) &r.left, sizeof(r.left));
  RegSetValueEx(k, "yPos",  0, REG_BINARY, (LPCSTR) &r.top,  sizeof(r.top));
  RegSetValueEx(k, "fg",    0, REG_BINARY, (LPCSTR) &fg,     sizeof(fg));
  RegSetValueEx(k, "bk",    0, REG_BINARY, (LPCSTR) &bk,     sizeof(bk));
  RegSetValueEx(k, "cust",  0, REG_BINARY, (LPCSTR) cust,    sizeof(COLORREF)*16);
  RegSetValueEx(k, "prcView",  0, REG_SZ,  (LPCSTR) prcView, strlen(prcView));
  RegSetValueEx(k, "prcViewExe",  0, REG_SZ,  (LPCSTR) prcViewExe, strlen(prcViewExe));
  RegCloseKey(k);
}

void LoadSettings(HWND hwnd)
{
  RECT r;
  HKEY k;
  DWORD t, s;
  CHAR  buf[80];  
  
  GetWindowRect(hwnd, &r);
  if (RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\DITJ\\MemStat",
                   0, KEY_READ, &k) != ERROR_SUCCESS)
    return;
  
  s = sizeof(bOnTop);
  RegQueryValueEx(k, "onTop", NULL, &t, (LPBYTE) &bOnTop, &s);
  s = sizeof(r.left);
  RegQueryValueEx(k, "xPos",  NULL, &t, (LPBYTE) &r.left, &s);
  s = sizeof(r.top);
  RegQueryValueEx(k, "yPos",  NULL, &t, (LPBYTE) &r.top, &s);
  s = sizeof(fg);
  RegQueryValueEx(k, "fg",    NULL, &t, (LPBYTE) &fg, &s);
  s = sizeof(bk);
  RegQueryValueEx(k, "bk",    NULL, &t, (LPBYTE) &bk, &s);
  s = sizeof(COLORREF) * 16;
  RegQueryValueEx(k, "cust",  NULL, &t, (LPBYTE) cust, &s);
  s = 256 /* sizeof(sizeof(prcView)) */;
  RegQueryValueEx(k, "prcView",NULL,&t, (LPBYTE) prcView, &s);
  s = 256 /* sizeof(sizeof(prcViewExe)) */;
  RegQueryValueEx(k, "prcViewExe",NULL,&t, (LPBYTE) prcViewExe, &s);
  RegCloseKey(k);
  
  SetWindowPos(hwnd, bOnTop ? HWND_TOPMOST : HWND_NOTOPMOST, 
               r.left, r.top, 0,0, 
               SWP_NOSIZE);

  CheckMenuItem(GetSystemMenu(hwnd, FALSE), 
                IDM_ONTOP, bOnTop ? MF_CHECKED : MF_UNCHECKED);
  sprintf(buf, "Start %s", prcView);
  
  ModifyMenu(GetSystemMenu(hwnd, FALSE), 
             IDM_PRCVIEW, MF_BYCOMMAND | MF_STRING, IDM_PRCVIEW,
             buf);
}

VOID SetProcView(HWND hwnd)
{
  OPENFILENAME of;
  CHAR buf[256], dir[256], *p;

  memset(&of, 0, sizeof(of));
  of.lStructSize = sizeof(of);
  of.lpstrTitle = "Select Program to start";
  of.hwndOwner = hwnd;
  of.lpstrFilter = "Executables\0*.exe;*.cmd;*.com;*.bat\0"
                   "All Files\0*.*\0\0";
  of.lpstrFile = prcViewExe;
  of.nMaxFile = 256;
  strcpy(dir, prcViewExe);
  if ((p = strrchr(dir, '\\')) != NULL)
  {
    p[1] = '\0';
    of.lpstrInitialDir = dir;
  }
  of.Flags = OFN_NOCHANGEDIR | OFN_HIDEREADONLY;
  if (!GetOpenFileName(&of))
    return;
  strcpy(prcView, &(prcViewExe[of.nFileOffset]));
  if (of.nFileExtension != 0)
    prcView[of.nFileExtension - of.nFileOffset - 1] = '\0';
  sprintf(buf, "Start %s", prcView);
  ModifyMenu(GetSystemMenu(hwnd, FALSE), 
             IDM_PRCVIEW, MF_BYCOMMAND | MF_STRING, IDM_PRCVIEW,
             buf);
}

VOID SetColor(HWND hwnd, BOOL bBk)
{
  CHOOSECOLOR cc;
  
  memset(&cc, 0, sizeof(cc));
  cc.lStructSize = sizeof(cc);
  cc.hwndOwner = hwnd;
  cc.rgbResult = bBk ? bk : fg;
  cc.lpCustColors = cust;
  cc.Flags = CC_RGBINIT;
  if (!ChooseColor(&cc))
    return;
  if (bBk)
  {
    LOGBRUSH lbr;
    bk = cc.rgbResult;
    lbr.lbStyle = BS_SOLID;
    lbr.lbColor = bk;
    DeleteObject(hbr);
    hbr = CreateBrushIndirect(&lbr);
  }
  else
    fg = cc.rgbResult;
} 

void StartProcView(VOID)
{
  char buf[80];
  sprintf(buf, "START %s", prcViewExe);
  system(buf);
}

void InitMain(HWND hwnd)
{
  HMENU sysMenu = GetSystemMenu(hwnd, FALSE);
  LOGBRUSH lbr;
  
  AppendMenu(sysMenu, MF_SEPARATOR, 0, NULL);
  AppendMenu(sysMenu, MF_STRING | MF_CHECKED, IDM_ONTOP,   "Always on top");
  AppendMenu(sysMenu, MF_STRING,              IDM_DEFPOS,  "Default Position");
  AppendMenu(sysMenu, MF_STRING,              IDM_PRCVIEW, "Start TaskMgr");
  AppendMenu(sysMenu, MF_SEPARATOR, 0, NULL);
  AppendMenu(sysMenu, MF_STRING,              IDM_OPTIONS, "Program...");
  AppendMenu(sysMenu, MF_STRING,              IDM_FGCOLOR, "Foreground...");
  AppendMenu(sysMenu, MF_STRING,              IDM_BGCOLOR, "Background...");
  AppendMenu(sysMenu, MF_SEPARATOR, 0, NULL);
  AppendMenu(sysMenu, MF_STRING,              IDM_ABOUT,   "About...");
  
  bk = RGB(0x00, 0x00, 0x00);
  fg = RGB(0x00, 0xFF, 0x00);
  lbr.lbStyle = BS_SOLID;
  lbr.lbColor = bk;
  hbr = CreateBrushIndirect(&lbr);
  
  bOnTop = TRUE;
  strcpy(prcView, "TaskMgr");
  strcpy(prcViewExe, "TaskMgr.EXE");
  CheckMenuItem(GetSystemMenu(hwnd, FALSE), IDM_ONTOP, MF_CHECKED);
  SetWindowPos(hwnd, HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE | SWP_NOSIZE);
  LoadSettings(hwnd);
  updateInfo(hwnd);
  if (!updWindowText)
    SetWindowText(hwnd, "MemStat");
  SetTimer(hwnd, ID_TIMER1, 1000, NULL);
}

int CALLBACK MainDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  static BOOL dragging = FALSE;
  static BOOL closing = FALSE;
  RECT r;
  
  switch (msg)
  {
    case WM_INITDIALOG:
      InitMain(hwnd);
      return(TRUE);
    
    case WM_CTLCOLORSTATIC:
      SetBkColor((HDC) wParam, bk);
      SetTextColor((HDC) wParam, fg);
      return((int) hbr);
      
    case WM_TIMER:
      updateInfo(hwnd);
      return(FALSE);
      
    case WM_CONTEXTMENU:
      TrackPopupMenu(GetSystemMenu(hwnd, FALSE), 
                     TPM_LEFTALIGN, LOWORD(lParam), HIWORD(lParam), 
                     0, hwnd, NULL);
      return(FALSE);
      
    case WM_COMMAND:
    case WM_SYSCOMMAND:
      switch(LOWORD(wParam))
      {
        case SC_CLOSE:
          closing = TRUE;
          SaveSettings(hwnd);
          KillTimer(hwnd, ID_TIMER1);
          DeleteObject(hbr);
          EndDialog(hwnd, 0);
          return(TRUE);
          
        case SC_MOVE:
          GetWindowRect(hwnd, &r);
          SetCursorPos(r.left, r.top);
          SetCapture(hwnd);
          dragging = TRUE;
          SetCursor(LoadCursor(0, IDC_CROSS));
          return(TRUE);
          
        case IDM_DEFPOS:
          SetWindowPos(hwnd, bOnTop ? HWND_TOPMOST : HWND_NOTOPMOST, 0,0,0,0, 
                       SWP_NOSIZE);
          bOnTop = !TRUE;
          /* FALL THROUGH ! */
        case IDM_ONTOP:
        {
          bOnTop = !bOnTop;
          CheckMenuItem(GetSystemMenu(hwnd, FALSE), IDM_ONTOP, bOnTop ? MF_CHECKED : MF_UNCHECKED);
          SetWindowPos(hwnd, bOnTop ? HWND_TOPMOST : HWND_NOTOPMOST, 0,0,0,0, 
                       SWP_NOMOVE | SWP_NOSIZE);
          SaveSettings(hwnd);
          return(TRUE);
        }
        case IDM_PRCVIEW:
          StartProcView();
          return(TRUE);
          
        case IDM_OPTIONS:
          SetProcView(hwnd);
          SaveSettings(hwnd);
          return(TRUE);
          
        case IDM_BGCOLOR:
        case IDM_FGCOLOR:
          SetColor(hwnd, LOWORD(wParam) == IDM_BGCOLOR);
          SaveSettings(hwnd);
          return(TRUE);
          
        case IDM_ABOUT:
          MessageBox(hwnd, "          � Thomas Johler 1998\n"
                           "Doubleclick to start your favourite Program\n"
                           "Drag to change position\n"
                           "Right button..., uh, you know already!", 
                     "MemStat",
                     MB_OK | MB_APPLMODAL);
          return(TRUE);
          
        default:
          return(FALSE);
      }
    case WM_LBUTTONDBLCLK:
      StartProcView();
      dragging = FALSE;
      ReleaseCapture();
      return(TRUE);
        
    case WM_LBUTTONDOWN:
    if (!dragging)
    {
      SetCapture(hwnd);
      dragging = TRUE;
      SetCursor(LoadCursor(0, IDC_CROSS));
    }
    return(TRUE);

    case WM_MOUSEMOVE:
      if (dragging)
      {
        int x, y;
        
        GetWindowRect(hwnd, &r);
        x = r.left + (short int) LOWORD(lParam);
        y = r.top  + (short int) HIWORD(lParam);
        SetWindowPos(hwnd,
                     bOnTop ? HWND_TOPMOST : HWND_NOTOPMOST, 
                     x, y, 0, 0, SWP_NOSIZE);
        SetCursor(LoadCursor(0, IDC_CROSS));
        return(TRUE);
      }
      return(FALSE);

    case WM_LBUTTONUP:
      if (dragging)
      {
        SaveSettings(hwnd);
        SetCursor(LoadCursor(0, IDC_ARROW));
        dragging = FALSE;
        ReleaseCapture();
      }
      return(TRUE);

    case WM_CLOSE:
      if (!closing)
        MessageBox(NULL, "Unexpected Closing of the window!", "MemStat",
                   MB_OK | MB_ICONERROR | MB_SYSTEMMODAL);
      return(FALSE);
    default:
      return(FALSE);
  }
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, 
                   LPSTR cmdLine, int nCmdShow)
{
  tzset();
  
  DialogBox(hInst, MAKEINTRESOURCE(IDD_MAIN), NULL, MainDlgProc);
  
  if (!strcmp(cmdLine, "/uw"))
    updWindowText = 1;
    
  return(0);
}