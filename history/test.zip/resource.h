//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by memstat.rc
//
#define IDI_MAIN                        101
#define IDM_ONTOP                       2000
#define IDM_PRCVIEW                     2001
#define IDM_DEFPOS                      2002
#define IDM_OPTIONS                     2003
#define IDM_FGCOLOR                     2004
#define IDM_BGCOLOR                     2005
#define IDM_ABOUT                       2006
#define IDM_LOW                         2007
#define IDM_NORMAL                      2008
#define IDM_HIGH                        2009
#define IDM_HIDE                        2010
#define IDM_UPDATE                      2011
#define IDS_ABOUT                       2012
#define IDS_PROGTITLE                   2013
#define IDS_FILTER0                     2014
#define IDS_FILTER1                     2015
#define IDS_PATHEXT                     3001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
